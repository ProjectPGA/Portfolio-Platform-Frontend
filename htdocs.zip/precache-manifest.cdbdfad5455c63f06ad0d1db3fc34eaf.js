self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fbcf2811961c87303146",
    "url": "/css/app.bfec1746.css"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/img/logo.82b9c7a5.png"
  },
  {
    "revision": "f75c4f2de5ffe3d78c6a02929918ab45",
    "url": "/index.html"
  },
  {
    "revision": "72091673565a89e15cf7",
    "url": "/js/about.9d5080f2.js"
  },
  {
    "revision": "fbcf2811961c87303146",
    "url": "/js/app.d45bd8d5.js"
  },
  {
    "revision": "03465a3613d429d069c2",
    "url": "/js/chunk-vendors.b5c2a91b.js"
  },
  {
    "revision": "07e5a5021c263dc77dd2919d4efbce7f",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);