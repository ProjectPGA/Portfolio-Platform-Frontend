export default class MainState {
    public testData: boolean = true;
}
