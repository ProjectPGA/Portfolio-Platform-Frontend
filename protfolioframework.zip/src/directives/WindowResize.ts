import { windowEventDirectiveFactory } from '@/directives/windowEventDirectiveFactory';

export const WindowResize = windowEventDirectiveFactory('resize');
