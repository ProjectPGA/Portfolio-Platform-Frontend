import { windowEventDirectiveFactory } from '@/directives/windowEventDirectiveFactory';

export const Scroll = windowEventDirectiveFactory('scroll');
