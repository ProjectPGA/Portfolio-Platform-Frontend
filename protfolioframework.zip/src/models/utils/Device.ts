export enum Device {
    sm = 'sm',
    md = 'md',
    lg = 'lg',
    xl = 'xl',
}
