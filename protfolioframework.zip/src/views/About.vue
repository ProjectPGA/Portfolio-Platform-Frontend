<template>
    <div></div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component({
    name: 'About',
})
export default class About extends Vue {}
</script>

<style lang="scss" scoped></style>
