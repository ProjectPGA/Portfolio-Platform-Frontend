const en = {};

export default en;
